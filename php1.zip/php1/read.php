<?php
error_reporting(0);
include("db.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Show Tabulize Data</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

</head>
<body>
<?php
$students=$obj->getAll("students","*");
echo "<pre>";
//print_r($students[0]);
/*$x=["a"=>"America","b"=>"Bangladesh","c"=>"Canada"];
foreach($x as $key=>$val){
	echo $key.":",$val,"<br>";
}*/
echo "</pre>";
?>
<div class="container">
	<?php
		if($_REQUEST['status']=='success'){
			echo "Insert Success";
		}

		if($_REQUEST['status']=='fail'){
			echo "Insert Fail";
		}

		if($_REQUEST['status']=='update_success'){
			echo "Update Success";
		}
		if($_REQUEST['status']=='update_fail'){
			echo "Update Fail";
		}

	?>
<table class="table table-bordered table-hover table-condensed table-stripped">
	<tr>
<?php
foreach($students[0] as $column=>$value){
	echo "<th>",ucfirst($column),"</th>";
}
	echo "<th>Action</th>";
?>
</tr>
<?php
$i=1;
foreach($students as $student){
	echo "<tr>";
		foreach($student as $val){
			echo "<td>$val</td>";
			$i++;
		}
		echo "<td><a class=\"btn btn-info\" href=\"edit.php?id=$student[id]\">Edit</a> | <a class=\"btn btn-danger\" href=\"delete.php?id=$student[id]\">Delete</a></td>";
	echo "</tr>";
}
?>
<tr>
	<td colspan="<?=$i;?>" class="text-center"><a href="insert.php" class="btn btn-primary">Add New Student</a></td>
</tr>
</table>
</div>

</body>
</html>