<!DOCTYPE html>
<html>
<head>
	<title>Add Student</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<body>
	<div class="container">
<form action="process.php" method="post">
	<table class="table table-bordered table-condensed">
	<tr>
		<th class="text-end">Name</th>
		<td><input class="form-control" placeholder="John Doe" type="text" name="name"></td>
	</tr>
	<tr>
		<th class="text-end">Mobile</th>
		<td><input class="form-control" type="text" name="mobile" placeholder="017XXXXXXX"></td>
	</tr>
	<tr>
		<th class="text-end">Address</th>
		<td><textarea name="address" class="form-control" placeholder="Dhaka,Bangladesh"></textarea></td>
	</tr>
	<tr>
		<td colspan="2" class="text-center"><input class="btn btn-info" type="submit" name="submit" value="Save"></td>
	</tr>
</table>
</form>
</div>
</body>
</html>