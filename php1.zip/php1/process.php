<?php
include("db.php");
/*echo "<pre>";
print_r($_REQUEST);
echo "</pre>";*/
/*$x=["a"=>"America","b"=>"Bangladesh","c"=>"Canada"];
$y=["America","Bangladesh","Chaina"];*/
/*extract($y,EXTR_PREFIX_ALL,"m");
echo $m_1;*/
//echo $a;

extract($_REQUEST);
if($obj->Insert("students","name='$name',mobile='$mobile',address='$address'")){
header("location:read.php?status=success");
}
else{
	header("location:read.php?status=fail");
}
?>