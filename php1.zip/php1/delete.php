<?php
include("db.php");
if(isset($_REQUEST['id'])){
	$id=$_REQUEST['id'];
}

if(isset($_REQUEST['c_id'])){
	$c_id=$_REQUEST['c_id'];

	if($obj->Delete("students","id=$c_id")){
header("location:read.php?status=delete_success");
}
else{
	header("location:read.php?status=delete_fail");
}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add Student</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<body>
	<div class="container">
		<span class="text-info">Do you want to Delete? <a href="delete.php?c_id=<?=$id;?>" class="btn btn-danger">Yes</a>&nbsp;<a href="read.php" class="btn btn-info">No</a>
</div>
</body>
</html>